@echo off
:: --- Auto-Elevate to Admin ---
if "%PROCESSOR_ARCHITECTURE%" EQU "amd64" (
>nul 2>&1 "%SYSTEMROOT%\SysWOW64\cacls.exe" "%SYSTEMROOT%\SysWOW64\config\system"
) else (
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
)
if '%errorlevel%' NEQ '0' (
    echo Requesting administrative privileges...
    goto UACPrompt
) else ( goto gotAdmin )
:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    set params = %*:"=""
    echo UAC.ShellExecute "cmd.exe", "/c ""%~s0"" %params%", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B
:gotAdmin
pushd "%cd%"
CD /D "%~dp0"

title MOUCLASS MAX-SYNC (ADMIN)
reg add "HKLM\SYSTEM\CurrentControlSet\Services\mouclass\Parameters" /v "MouseDataQueueSize" /t REG_DWORD /d 16 /f
for /f "tokens=*" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Enum" /s /f "Device Parameters" ^| findstr "mouclass"') do (
    reg add "%%a" /v "MouseDataQueueSize" /t REG_DWORD /d 100 /f
    reg add "%%a" /v "WaitWakeEnabled" /t REG_DWORD /d 0 /f
    reg add "%%a" /v "EnhancedPowerManagementEnabled" /t REG_DWORD /d 0 /f
)
echo MOUCLASS Optimized!
timeout /t 3